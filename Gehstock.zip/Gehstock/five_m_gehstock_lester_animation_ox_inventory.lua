-- FiveM Gehstock Item Script
-- ox_inventory | Lester Crest Animation | Server-Sync | Auto-Remove im Fahrzeug

-- =====================
-- CONFIG
-- =====================
local Cane = {
    model = `prop_cs_walking_stick`, -- Holz-Gehstock
    animDict = 'amb@world_human_hang_out_street@male_c@idle_a',
    animName = 'idle_b',
    walkStyle = 'move_lester_CaneUp',
    attached = false,
    entity = nil
}

-- =====================
-- UTILS
-- =====================
local function loadModel(model)
    RequestModel(model)
    while not HasModelLoaded(model) do Wait(10) end
end

local function loadAnim(dict)
    RequestAnimDict(dict)
    while not HasAnimDictLoaded(dict) do Wait(10) end
end

local function loadClipset(clipset)
    RequestAnimSet(clipset)
    while not HasAnimSetLoaded(clipset) do Wait(10) end
end

local function removeCane(ped)
    if Cane.attached then
        ClearPedTasks(ped)
        ResetPedMovementClipset(ped, 0.0)
        if DoesEntityExist(Cane.entity) then
            DeleteEntity(Cane.entity)
        end
        Cane.entity = nil
        Cane.attached = false
        TriggerServerEvent('cane:sync', false)
    end
end

-- =====================
-- MAIN EVENT
-- =====================
RegisterNetEvent('cane:use', function()
    local ped = PlayerPedId()

    if IsPedInAnyVehicle(ped, false) then return end

    if Cane.attached then
        removeCane(ped)
        return
    end

    loadModel(Cane.model)
    loadAnim(Cane.animDict)
    loadClipset(Cane.walkStyle)

    local coords = GetEntityCoords(ped)
    local cane = CreateObject(Cane.model, coords.x, coords.y, coords.z, true, true, true)

    AttachEntityToEntity(
        cane,
        ped,
        GetPedBoneIndex(ped, 57005), -- rechte Hand
        0.12, 0.03, -0.02,
        -90.0, 0.0, 10.0,
        true, true, false, true, 1, true
    )

    TaskPlayAnim(ped, Cane.animDict, Cane.animName, 8.0, -8.0, -1, 49, 0, false, false, false)
    SetPedMovementClipset(ped, Cane.walkStyle, 1.0)

    Cane.entity = cane
    Cane.attached = true

    TriggerServerEvent('cane:sync', true)
end)

-- =====================
-- AUTO REMOVE IM FAHRZEUG
-- =====================
CreateThread(function()
    while true do
        Wait(500)
        local ped = PlayerPedId()
        if Cane.attached and IsPedInAnyVehicle(ped, false) then
            removeCane(ped)
        end
    end
end)

-- =====================
-- SERVER SYNC (ANDERE SPIELER)
-- =====================
RegisterNetEvent('cane:syncClient', function(sourceId, state)
    local target = GetPlayerFromServerId(sourceId)
    if target == -1 then return end

    local ped = GetPlayerPed(target)
    if not DoesEntityExist(ped) then return end

    if state then
        loadModel(Cane.model)
        local coords = GetEntityCoords(ped)
        local cane = CreateObject(Cane.model, coords.x, coords.y, coords.z, false, false, false)

        AttachEntityToEntity(
            cane,
            ped,
            GetPedBoneIndex(ped, 57005),
            0.12, 0.03, -0.02,
            -90.0, 0.0, 10.0,
            true, true, false, true, 1, true
        )

        SetPedMovementClipset(ped, Cane.walkStyle, 1.0)
    else
        ClearPedTasks(ped)
        ResetPedMovementClipset(ped, 0.0)
    end
end)

-- =============================
-- SERVER-SIDE (server.lua)
-- =============================
-- RegisterNetEvent('cane:sync')
-- AddEventHandler('cane:sync', function(state)
--     TriggerClientEvent('cane:syncClient', -1, source, state)
-- end)

-- =============================
-- ox_inventory Item Definition
-- =============================
-- ox_inventory/data/items.lua
-- ['cane'] = {
--     label = 'Holz-Gehstock',
--     weight = 600,
--     stack = false,
--     close = true,
--     description = 'Ein klassischer Holzgehstock',
--     client = {
--         event = 'cane:use'
--     }
-- }
